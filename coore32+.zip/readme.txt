                                                    /$$$$$$   /$$$$$$          
                                                   /$$__  $$ /$$__  $$   /$$   
  /$$$$$$$  /$$$$$$   /$$$$$$   /$$$$$$   /$$$$$$ |__/  \ $$|__/  \ $$  | $$   
 /$$_____/ /$$__  $$ /$$__  $$ /$$__  $$ /$$__  $$   /$$$$$/  /$$$$$$//$$$$$$$$
| $$      | $$  \ $$| $$  \ $$| $$  \__/| $$$$$$$$  |___  $$ /$$____/|__  $$__/
| $$      | $$  | $$| $$  | $$| $$      | $$_____/ /$$  \ $$| $$        | $$   
|  $$$$$$$|  $$$$$$/|  $$$$$$/| $$      |  $$$$$$$|  $$$$$$/| $$$$$$$$  |__/   
 \_______/ \______/  \______/ |__/       \_______/ \______/ |________/         (normal coore32.exe by kapi2.0peys)
coore32+.exe by x1n3mot3

Made with Visual Studio Code, Vbs To Exe and VBScript.

This malware gives 4 warnings to warn the user, and letting them know this is a malware.

!!Please do not maliciously run these kind of malwares on other peoples computers or public computers.!!

This malware is a safe malware, but i still recommend to run in a VM.
  ___ _   _ _  _     _ _____  __   _____  _   _ _ ___ ___    _____      ___  _   ___ ___ ___ _  ___ 
 | _ \ | | | \| |   /_\_   _| \ \ / / _ \| | | ( ) _ \ __|  / _ \ \    / / \| | | _ \_ _/ __| |/ / |
 |   / |_| | .` |  / _ \| |    \ V / (_) | |_| |/|   / _|  | (_) \ \/\/ /| .` | |   /| |\__ \ ' <|_|
 |_|_\\___/|_|\_| /_/ \_\_|     |_| \___/ \___/  |_|_\___|  \___/ \_/\_/ |_|\_| |_|_\___|___/_|\_(_)
                                                                                                    
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Note: If "coore32+.exe" does not work, run "coore32+.vbs" instead, Do NOT mess with the .wav or gdi effect .exe files, don't Rename, delete or move them, if you
do any of those, then the GDI effects or sounds wont work. And also, make sure you install Windows Media Player, if not, the bytebeats will not play. So make sure
that Windows Media Player is installed before you run this.
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

You can download the coore32+.exe only, but you also have to download the GDI effects (those .exes) and the .wav files if you are only gonna download coore32+.exe.

Works in Windows 7 to Windows 11.



this malware is ass bro, and its nothing like the real coore32.exe btw
